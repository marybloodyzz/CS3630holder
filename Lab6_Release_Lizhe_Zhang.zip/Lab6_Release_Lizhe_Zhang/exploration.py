from robot import Robot
from utils import *
import math
import time

def get_wheel_velocities(robbie, coord):
    """
    Helper function to determine the velocities of the robot's left and right wheels.
    Arguments:
        robbie: instance of the robot
        coord (tuple): coordinate to move to (x,y)
    
    Returns: 
        vr, vl: velocities of the robot's left and right wheels
    """

    # Calculate the desired change in position
    dx_world = coord[0] - robbie.x
    dy_world = coord[1] - robbie.y
    dx_robot, dy_robot = rotate_point(dx_world, dy_world, robbie.h)
    dist_to_coord = math.sqrt(dx_robot**2 + dy_robot**2)
    
    # Turn in place first
    angle = math.atan2(dy_robot, dx_robot)
    threshold = 0.1
    if angle < -threshold:
        return -0.01, 0.01
    elif angle > threshold:
        return 0.01, -0.01
    
    # Using desired linear velocity, set left and right wheel velocity
    linear_v = 0.05 * dist_to_coord
    w = 0.3 * math.atan2(dy_robot, dx_robot)
    vl = (linear_v - robbie.wheel_dist / 2 * w) 
    vr = (linear_v + robbie.wheel_dist / 2 * w)    
    return vr, vl

def identify_frontiers(grid, robbie):
    frontiers = []
    for x in range(grid.width):
        for y in range(grid.height):
            if grid.is_free(x, y) and is_adjacent_to_unexplored(x, y, grid, robbie):
                frontiers.append((x, y))
    return frontiers

def is_adjacent_to_unexplored(x, y, grid, robbie):
    directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    for dx, dy in directions:
        nx, ny = x + dx, y + dy
        if grid.is_in(nx, ny) and (nx, ny) not in robbie.explored_cells:
            return True
    return False

def select_frontier(frontiers, robbie):
    if not frontiers:
        return None
    closest_frontier = min(frontiers, key=lambda coord: grid_distance(coord[0], coord[1], robbie.x, robbie.y))
    return closest_frontier

def frontier_planning(robbie, grid):
    frontiers = identify_frontiers(grid, robbie)
    next_coord = select_frontier(frontiers, robbie)
    robbie.next_coord = next_coord
    return robbie

def exploration_state_machine(robbie, grid):
    if robbie.next_coord is None:
        robbie = frontier_planning(robbie, grid)


    if grid.is_collision_with_obstacles((robbie.x, robbie.y), robbie.next_coord):
        robbie.path = grid.rrt((robbie.x, robbie.y), robbie.next_coord)
        if robbie.path:
            robbie.next_coord = robbie.path.pop(1)  
        else:
            robbie.next_coord = None
            return robbie  
    reach_threshold = 0.1  
    if grid_distance(robbie.x, robbie.y, robbie.next_coord[0], robbie.next_coord[1]) < reach_threshold:
        robbie.explored_cells.add(robbie.next_coord)
        robbie.next_coord = None
    
    
    if robbie.next_coord is None:
        robbie = frontier_planning(robbie, grid)

        if robbie.next_coord is None:
            print("Exploration phase complete.")
            return robbie

    if robbie.next_coord:
        robbie.vr, robbie.vl = get_wheel_velocities(robbie, robbie.next_coord)
        robbie.move_diff_drive(grid, robbie.vl, robbie.vr, robbie.TIMESTEP)
        robbie.explored_cells.update(robbie.get_cells_in_fov(grid))


    return robbie
