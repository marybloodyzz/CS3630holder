from grid import *
from robot import *
import time
import math
from utils import *

count = 0
def get_wheel_velocities(robbie, coord, pickup_marker=False, threshold=0.1):
    """
    Helper function to determine the velocities of the robot's left and right wheels.
    Arguments:
        robbie: instance of the robot
        coord (tuple): coordinate to move to (x,y)
        pickup_marker (bool): Only set to 'True' when picking up marker
        threshold (int): Set to expected heading when trying to align robot with marker
    
    Returns: 
        vr, vl: velocities of the robot's left and right wheels
    """

    # Calculate the desired change in position
    controller = PidController()
    dx_world = coord[0] - robbie.x
    dy_world = coord[1] - robbie.y
    dx_robot, dy_robot = rotate_point(dx_world, dy_world, robbie.h)
    
    # Turn in place
    if not pickup_marker:
        angle = math.atan2(dy_robot, dx_robot)
        if angle < -threshold:
            return -0.02, 0.02
        elif angle > threshold:
            return 0.02, -0.02
    else:
        angle = robbie.h
        if angle < threshold:
            return 0.02, -0.02
        elif angle > threshold:
            return -0.02, 0.02
    
    
    robot_pose = np.array([robbie.xyh[0], robbie.xyh[1], robbie.xyh[2]])
    goalpoint = np.array([coord[0], coord[1]])
    linear_v = controller.linear_controller(robot_pose, goalpoint)
    w = controller.angular_controller(robot_pose, goalpoint) 
    

    vl = (linear_v - robbie.wheel_dist / 2 * w) 
    vr = (linear_v + robbie.wheel_dist / 2 * w)    
    return vr, vl


def phase2_planning(robbie, grid):
    global count
    for marker in grid.markers:

        marker_x, marker_y, marker_heading = parse_marker_info(marker[0], marker[1], marker[2])

        reach_threshold = 0.2
        
        while grid_distance(robbie.x, robbie.y, marker_x, marker_y) > reach_threshold:
            robbie.path = grid.rrt((robbie.x, robbie.y), (marker_x, marker_y))
            robbie.next_coord = robbie.path.pop(1)


            if grid.is_collision_with_obstacles((robbie.x, robbie.y), robbie.next_coord):
                robbie.path = grid.rrt((robbie.x, robbie.y), (marker_x, marker_y))

                if robbie.path:
                    robbie.next_coord = robbie.path.pop(1)
                    robbie.vr, robbie.vl = get_wheel_velocities(robbie, robbie.next_coord)
                    robbie.move_diff_drive(grid,robbie.vl, robbie.vr, robbie.TIMESTEP)
                    return robbie
                

            

            else:
                robbie.path = grid.rrt((robbie.x, robbie.y), (marker_x, marker_y))

                if robbie.path:
                    robbie.next_coord = robbie.path.pop(1)
                    robbie.vr, robbie.vl = get_wheel_velocities(robbie, robbie.next_coord)

                    robbie.move_diff_drive(grid,robbie.vl, robbie.vr, robbie.TIMESTEP)
                    return robbie


            robbie.explored_cells.update(robbie.get_cells_in_fov(grid))
        


        orientation_threshold = 10
        while diff_heading_deg(robbie.h, marker_heading) > orientation_threshold:
            robbie.vr, robbie.vl = 0, 0.012
            robbie.move_diff_drive(grid, robbie.vl, robbie.vr, robbie.TIMESTEP)
            return robbie

        if diff_heading_deg(robbie.h, marker_heading) <= orientation_threshold:
            count += 1
            robbie.pickup_marker(grid)

            if(count == 10):
                grid.markers.remove(marker)
                count = 0
            
            return robbie
        return robbie



    
